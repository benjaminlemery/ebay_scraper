import requests
import urllib.request
from bs4 import BeautifulSoup

quote_page = "https://www.ebay.com/sch/i.html?_from=R40&_trksid=p2499334.m570.l1313.TR0.TRC0.A0.H0.Xlg+g5+rs988.TRS1&_nkw=lg+g5+rs988&_sacat=9355"

# Query the website and return the html output to the variable.
page = urllib.request.urlopen(quote_page)

# Parse the html using beautiful soup and store in variable soup
soup = BeautifulSoup(page,'html.parser')

for find_url in soup.find_all('a',class_='s-item__link',href=True):
    #print(find_url)
    print(find_url['href'])



#ame = soup.find('h1',class_='it-ttl').text.strip("Details about")
 #       print(name)