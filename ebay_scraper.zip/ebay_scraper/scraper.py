import requests
import urllib.request
from bs4 import BeautifulSoup

# The URL to be scraped
quote_page = "https://www.ebay.com/itm/LG-G5-RS988-32GB-Smartphone-Unlocked-Titan/113904918561?epid=19011409741&hash=item1a85432021:g:v1IAAOSwQ4RdjnBk"

# Query the website and return the html output to the variable.
page = urllib.request.urlopen(quote_page)

# Parse the html using beautiful soup and store in variable soup
soup = BeautifulSoup(page,'html.parser')

# for quote_page in soup.find_all('a',class_="s-item_link"):
# Grabs the items name
name = soup.find('h1',class_='it-ttl').text.strip("Details about")
print(name)

# Grabs the items price
price = soup.find('span',class_='notranslate').text
print(price)

# Grabs the item condition
item_condition = soup.find('div',class_='u-flL condText').text
print(item_condition)


# Grabs the items shipping price (Does not work)
#shipping_price = soup.find('span',class_='notranslate sh-cst').text
#print(shipping_price)

# Grabs Return Information (Does not work)
#return_information = soup.find('span',class_=" vi-no-ret-accrd-txt").text
#print(return_information)




